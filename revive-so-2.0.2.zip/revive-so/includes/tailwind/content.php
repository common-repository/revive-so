<?php
/**
 * The content of the application.
 */

/**
 * Action trigger to display the content of the admin page.
 *
 * @hook  reviveso_admin_page_content
 * @since 2.0.0
 */
do_action( 'reviveso_admin_page_content', $this );
